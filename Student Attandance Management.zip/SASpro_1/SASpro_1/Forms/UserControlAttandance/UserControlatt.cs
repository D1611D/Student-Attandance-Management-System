﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace SASpro_1.Forms.UserControlAttandance
{
    public partial class UserControlatt : UserControl
    {
        //private string sql = @"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True";
        private string sql = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";
        private bool okay;

        public UserControlatt()
        {
            InitializeComponent();
            //this.Load += UserControlatt_Load;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;


            // Make sure the columns "Column4" and "Column5" exist in your DataGridView
            dataGridViewatt1.Columns["Column4"].Visible = false;
            dataGridViewatt1.Columns["Column5"].Visible = false;
        }

        private void UserControlatt_Load(object sender, EventArgs e)
        {
            // Set DateTimePicker's min and max date to today
            dateTimePicker1.MinDate = DateTime.Today;
            dateTimePicker1.MaxDate = DateTime.Today;

            // Set the default value to today
            dateTimePicker1.Value = DateTime.Today;

            // Handle ValueChanged event
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            // Check if the selected date is different from today
            if (dateTimePicker1.Value.Date != DateTime.Today)
            {
                MessageBox.Show("You can only mark attendance for the current date.", "Invalid Date Selection", MessageBoxButtons.OK, MessageBoxIcon.Error);

                // Reset the DateTimePicker value back to today's date
                dateTimePicker1.Value = DateTime.Today;
            }
        }


        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Please select a class.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(sql))
            {
                connection.Open();
//                MessageBox.Show("Connection opened successfully!");

                // Check if attendance is already marked for the selected date and class
                if (IsmarkAttandance(dateTimePicker1.Text, comboBox2.SelectedItem.ToString(), connection))
                {
                    string query = @"SELECT Student_info.Student_id, Student_name, Student_rollno, Attandance_Status 
                             FROM Student_info 
                             INNER JOIN Attandance_tbl ON Student_info.Student_id = Attandance_tbl.Student_id 
                             INNER JOIN Class_info ON Class_info.Class_id = Student_info.Class_id 
                             WHERE attandance_date = @date AND Class_name = @className;";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@date", DateTime.Parse(dateTimePicker1.Text));
                        cmd.Parameters.AddWithValue("@className", comboBox2.SelectedItem.ToString());
                        DisplayAndSearchAllData(cmd, dataGridViewatt1);
                    }

                    okay = true;
                }
                else
                {
                    // If attendance is not marked, show only the student info
                    string query = @"SELECT Student_id, Student_name, Student_rollno 
                             FROM Student_info 
                             INNER JOIN Class_info ON Class_info.Class_id = Student_info.Class_id 
                             WHERE Class_name = @className;";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@className", comboBox2.SelectedItem.ToString());
                        DisplayAndSearchAllData(cmd, dataGridViewatt1);
                    }

                    okay = false;
                }
            }
        }



        private static void DisplayAndSearchAllData(SqlCommand cmd, DataGridView dataGridViewatt1)
        {
           
            try
            {
                using (SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd))
                {
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    // Bind data to the DataGridView once after the data is filled
                    dataGridViewatt1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private static bool IsmarkAttandance(string date, string className, SqlConnection connection)
        {
            //string query = "SELECT COUNT(*) FROM Attandance_tbl " +
            //               "INNER JOIN Class_info1 ON Class_info1.Class_id = Attandance_tbl.Class_id " +
            //               "WHERE attandance_date = @date AND Class_name = @className";
            string query = "SELECT COUNT (*) FROM Attandance_tbl INNER JOIN Class_info ON Class_info.Class_id = Attandance_tbl.Attandance_id WHERE attandance_date = @date AND Class_name = @className";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@date", date);
                    cmd.Parameters.AddWithValue("@className", className);


                    // Open the connection if it's not already open
                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                    }

                    // Execute the query and check if any rows match the criteria
                    int result = (int)cmd.ExecuteScalar();
                    return result > 0;
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }

        }

        private void comboBox2_Click(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            FillCombobox("SELECT DISTINCT(Class_name) FROM Class_info;", comboBox2);
        }

        private static void FillCombobox(string query, ComboBox comboBox2)
        {
            //string connectionString = @"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True";
            string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";
            
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                comboBox2.Items.Add(reader["Class_name"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void tabPagemat_Leave(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex != -1)
            {
                string status;
                using (SqlConnection connection = new SqlConnection(sql))
                {
                    connection.Open();
                    bool isAttendanceMarked = IsmarkAttandance(dateTimePicker1.Text, comboBox2.SelectedItem.ToString(), connection);

                    foreach (DataGridViewRow row in dataGridViewatt1.Rows)
                    {
                        status = Convert.ToBoolean(row.Cells["Column3"].EditedFormattedValue) ? "Present" : "Absent";
                        UpdateAttandance(row.Cells["Column1"].Value.ToString(), dateTimePicker1.Text, status, connection);
                    }
                    connection.Close();
                }
            }
        }


        private static void UpdateAttandance(string studentId, string date, string status, SqlConnection connection)
        {
            //string query = "UPDATE Attandance_tbl SET Status = @status " +
            //               "WHERE Student_id = @studentId AND attandance_Date = @date";
            string query = "UPDATE Attandance_tbl SET Attandance_Status = @status WHERE Student_id = @studentid AND attandance_Date = @date";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@studentId", studentId);
                    cmd.Parameters.AddWithValue("@date", date);
                    cmd.Parameters.AddWithValue("@status", status);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Error: " + ex.Message);

            }
        }

       
        private void dataGridViewatt1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            // Ensure that the column index matches the "Column4" (the status column)
            if (e.ColumnIndex == dataGridViewatt1.Columns["Column4"].Index)
            {
                // Check if the "Column3" (checkbox) is true or false
                bool isChecked = Convert.ToBoolean(dataGridViewatt1.Rows[e.RowIndex].Cells["Column3"].Value);

                // Set the value of "Column4" to "Present" if checked, else "Absent"
                e.Value = isChecked ? "Present" : "Absent";
            }
        }



        public SqlConnection connection { get; set; }

        private void dataGridViewatt1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if (e.ColumnIndex == dataGridViewatt1.Columns["Column3"].Index) // Check if it's the checkbox column
            {
                DataGridViewCheckBoxCell checkBoxCell = (DataGridViewCheckBoxCell)dataGridViewatt1.Rows[e.RowIndex].Cells["Column3"];
                bool isChecked = !(Convert.ToBoolean(checkBoxCell.Value)); // Toggle value
                checkBoxCell.Value = isChecked; // Set the new value
                dataGridViewatt1.EndEdit(); // Commit changes

                // Retrieve Student ID and Date for the current row
                string studentId = dataGridViewatt1.Rows[e.RowIndex].Cells["Column5"].Value.ToString();
                string attendanceDate = dateTimePicker1.Value.ToString("yyyy-MM-dd"); // Assuming date picker holds the date

                // Determine the status based on the checkbox value
                string status = isChecked ? "Present" : "Absent";

                // Call the method to insert/update the attendance status
                InsertAttendanceStatus(studentId, attendanceDate, status);
            }
        }

        private void InsertAttendanceStatus(string studentId, string attendanceDate, string status)
        {
            string insertQuery = "INSERT INTO Attandance_tbl (Student_id, Attandance_Date, Attandance_Status) " +
                         "VALUES (@studentId, @date, @status);";

            try
            {
                using (SqlConnection connection = new SqlConnection(sql))
                {
                    connection.Open();

                    // Get the attendance date from the DateTimePicker
                    string attendanceDateLocal = dateTimePicker1.Value.ToString("yyyy-MM-dd");

                    foreach (DataGridViewRow row in dataGridViewatt1.Rows) // Loop through each row
                    {
                        // Check if the Student ID cell exists and is not null
                        if (row.Cells["Column5"] != null && row.Cells["Column5"].Value != null)
                        {
                            string studentIdLocal = row.Cells["Column5"].Value.ToString();

                            // Check if the checkbox cell is not null and handle the checkbox state
                            bool isChecked = row.Cells["Column3"].Value != null && row.Cells["Column3"].Value != DBNull.Value && (bool)row.Cells["Column3"].FormattedValue;

                            // Set the status based on the checkbox value
                            string statusLocal = isChecked ? "Present" : "Absent";

                            using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                            {
                                cmd.Parameters.AddWithValue("@studentId", studentIdLocal);
                                cmd.Parameters.AddWithValue("@date", attendanceDateLocal); // Use the date from DateTimePicker
                                cmd.Parameters.AddWithValue("@status", statusLocal);

                                cmd.ExecuteNonQuery(); // Execute the insert query
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inserting attendance status: " + ex.Message);
            }
        }

      


    }  
 }

