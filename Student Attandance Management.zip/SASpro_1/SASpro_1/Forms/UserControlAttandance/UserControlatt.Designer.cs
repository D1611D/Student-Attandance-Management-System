﻿namespace SASpro_1.Forms.UserControlAttandance
{
    partial class UserControlatt
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControlatt = new System.Windows.Forms.TabControl();
            this.tabPagemat = new System.Windows.Forms.TabPage();
            this.dataGridViewatt1 = new System.Windows.Forms.DataGridView();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelname = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControlatt.SuspendLayout();
            this.tabPagemat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewatt1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControlatt
            // 
            this.tabControlatt.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControlatt.Controls.Add(this.tabPagemat);
            this.tabControlatt.Location = new System.Drawing.Point(0, 0);
            this.tabControlatt.Name = "tabControlatt";
            this.tabControlatt.SelectedIndex = 0;
            this.tabControlatt.Size = new System.Drawing.Size(1111, 501);
            this.tabControlatt.TabIndex = 0;
            // 
            // tabPagemat
            // 
            this.tabPagemat.BackColor = System.Drawing.Color.Lavender;
            this.tabPagemat.Controls.Add(this.dataGridViewatt1);
            this.tabPagemat.Controls.Add(this.dateTimePicker1);
            this.tabPagemat.Controls.Add(this.panel1);
            this.tabPagemat.Controls.Add(this.panelname);
            this.tabPagemat.Controls.Add(this.comboBox2);
            this.tabPagemat.Controls.Add(this.label3);
            this.tabPagemat.Controls.Add(this.label2);
            this.tabPagemat.Controls.Add(this.label1);
            this.tabPagemat.Location = new System.Drawing.Point(4, 4);
            this.tabPagemat.Name = "tabPagemat";
            this.tabPagemat.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagemat.Size = new System.Drawing.Size(1103, 475);
            this.tabPagemat.TabIndex = 0;
            this.tabPagemat.Text = "Mark Attandance";
            this.tabPagemat.Leave += new System.EventHandler(this.tabPagemat_Leave);
            // 
            // dataGridViewatt1
            // 
            this.dataGridViewatt1.AllowUserToAddRows = false;
            this.dataGridViewatt1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewatt1.BackgroundColor = System.Drawing.Color.Lavender;
            this.dataGridViewatt1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewatt1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dataGridViewatt1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridViewatt1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewatt1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column4,
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column5});
            this.dataGridViewatt1.Location = new System.Drawing.Point(62, 165);
            this.dataGridViewatt1.Name = "dataGridViewatt1";
            this.dataGridViewatt1.ReadOnly = true;
            this.dataGridViewatt1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridViewatt1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridViewatt1.Size = new System.Drawing.Size(872, 282);
            this.dataGridViewatt1.TabIndex = 2;
            this.dataGridViewatt1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewatt1_CellContentClick);
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "Student_id";
            this.Column4.HeaderText = "id";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Student_name";
            this.Column1.HeaderText = "Student Name";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "Student_rollno";
            this.Column2.HeaderText = "Rollno";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "Attandance_Status";
            this.Column3.HeaderText = "Att. Status";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "Student_id";
            this.Column5.HeaderText = "Student_id";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy/MM/dd";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(142, 102);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(232, 20);
            this.dateTimePicker1.TabIndex = 1;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Blue;
            this.panel1.Location = new System.Drawing.Point(517, 128);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(232, 2);
            this.panel1.TabIndex = 1;
            // 
            // panelname
            // 
            this.panelname.BackColor = System.Drawing.Color.Blue;
            this.panelname.Location = new System.Drawing.Point(142, 128);
            this.panelname.Name = "panelname";
            this.panelname.Size = new System.Drawing.Size(232, 2);
            this.panelname.TabIndex = 1;
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(517, 101);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(232, 21);
            this.comboBox2.TabIndex = 0;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            this.comboBox2.Click += new System.EventHandler(this.comboBox2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(514, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 18);
            this.label3.TabIndex = 0;
            this.label3.Text = "Class";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(139, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 18);
            this.label2.TabIndex = 0;
            this.label2.Text = "Date";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(17, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mark Attandance...";
            // 
            // UserControlatt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControlatt);
            this.Name = "UserControlatt";
            this.Size = new System.Drawing.Size(1024, 518);
            this.tabControlatt.ResumeLayout(false);
            this.tabPagemat.ResumeLayout(false);
            this.tabPagemat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewatt1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlatt;
        private System.Windows.Forms.TabPage tabPagemat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelname;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridView dataGridViewatt1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;

    }
}
