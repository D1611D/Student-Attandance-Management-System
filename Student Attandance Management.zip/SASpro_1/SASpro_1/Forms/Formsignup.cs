﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SASpro_1
{
    public partial class Formsignup : Form
    {
      //  SqlDataAdapter ad;
        SqlConnection con;
        SqlCommand cd;
      //  DataSet ds;

        public Formsignup()
        {
            InitializeComponent();

            errorProvider1.SetIconAlignment(textBox2, ErrorIconAlignment.MiddleRight);
            errorProvider1.SetIconPadding(textBox2, 2);

            errorProvider2.SetIconAlignment(textBox3, ErrorIconAlignment.MiddleRight);
            errorProvider2.SetIconPadding(textBox3, 2);
        }

        private void pictureBoxClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Formsignup_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Dhairya Sem 5\projectdb\projectdb1.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form Login = new Login();
            Login.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                errorProvider1.SetError(textBox2, "Please enter a value.");
                e.Cancel = true;
            }
            else
            {
               errorProvider1.Clear();
            }
           
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBox3.Text))
            {
                errorProvider1.SetError(textBox3, "Please enter password.");
                e.Cancel = true;
            }
            else
            {
                errorProvider1.Clear();
            }
        }

      

        private void textBox4_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBox4.Text))
            {
                errorProvider1.SetError(textBox4, "Please enter email.");
                e.Cancel = true;
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void textBox5_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBox5.Text))
            {
                errorProvider1.SetError(textBox5, "Please enter Contact.");
                e.Cancel = true;
            }
            else
            {
                errorProvider1.Clear();
            }
        }

       

        private void button1_Click_2(object sender, EventArgs e)
        {

        //    cd = new SqlCommand("insert into projectdb (id,Name,Username,Password,Email,Contact)values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "'," + textBox6.Text + ")", con);
        //    cd.ExecuteNonQuery();
        //    textBox1.Clear();
        //    textBox2.Clear();
        //    textBox3.Clear();
        //    textBox4.Clear();
        //    textBox5.Clear();
        //    textBox6.Clear();
            
        //    this.Hide();
        //    Form Login = new Login();
        //    Login.ShowDialog();
        //    this.Close();
       }

        private void linkLabel1_LinkClicked_2(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Login f1 = new Login();

            f1.ShowDialog();
            this.Close();
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                errorProvider1.SetError(textBox1, "Please enter a value.");
                e.Cancel = true;
            }
            else
            {
                errorProvider1.Clear();
            }

            if (string.IsNullOrEmpty(textBox2.Text))
            {
                errorProvider1.SetError(textBox2, "Please enter a value.");
                e.Cancel = true;
            }
            else
            {
                errorProvider1.Clear();
            }

            if (string.IsNullOrEmpty(textBox3.Text))
            {
                errorProvider1.SetError(textBox3, "Please enter a value.");
                e.Cancel = true;
            }
            else
            {
                errorProvider1.Clear();
            }

            if (string.IsNullOrEmpty(textBox4.Text))
            {
                errorProvider1.SetError(textBox4, "Please enter a value.");
                e.Cancel = true;
            }
            else
            {
                errorProvider1.Clear();
            }

            if (string.IsNullOrEmpty(textBox5.Text))
            {
                errorProvider1.SetError(textBox5, "Please enter a value.");
                e.Cancel = true;
            }
            else
            {
                errorProvider1.Clear();
            }

            if (string.IsNullOrEmpty(textBox6.Text))
            {
                errorProvider1.SetError(textBox6, "Please enter a value.");
                e.Cancel = true;
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}

