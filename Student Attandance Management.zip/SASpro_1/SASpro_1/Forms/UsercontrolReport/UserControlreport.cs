﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SASpro_1.Forms.UsercontrolReport
{
    public partial class UserControlreport : UserControl
    {
        //private string query = @"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True";
        private string connectionstring = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";
       // private static SqlConnection connection;

        
        public UserControlreport()
        {
            InitializeComponent();
        }

        public void FirstTab()
        {
            tabControlrep.SelectedTab = tabPageclr;
        }

        private void UserControlreport_Load(object sender, EventArgs e)
        {
            // Allow any past date but not future dates
            dateTimePicker1.MaxDate = DateTime.Today;
            dateTimePicker2.MaxDate = DateTime.Today;

            // Set the default value to today
            dateTimePicker1.Value = DateTime.Today;
            dateTimePicker2.Value = DateTime.Today;

            // Handle ValueChanged event
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            dateTimePicker2.ValueChanged += dateTimePicker2_ValueChanged;
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            // Check if the selected date is in the future
            if (dateTimePicker2.Value.Date > DateTime.Today)
            {
                MessageBox.Show("There is no record for this date.", "Invalid Date Selection", MessageBoxButtons.OK, MessageBoxIcon.Error);

                // Reset the DateTimePicker value back to today's date
                dateTimePicker2.Value = DateTime.Today;
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            // Check if the selected date is in the future
            if (dateTimePicker1.Value.Date > DateTime.Today)
            {
                MessageBox.Show("There is no record for this date.", "Invalid Date Selection", MessageBoxButtons.OK, MessageBoxIcon.Error);

                // Reset the DateTimePicker value back to today's date
                dateTimePicker1.Value = DateTime.Today;
            }
        }

        private void comboxclass2_Click(object sender, EventArgs e)
        {
            //comboBoxclass.Items.Clear();
            //SASpro_1.Forms.UsercontrolReport.UserControlreport.FillCombobox("SELECT DISTINCT (Class_name) from class_info1;", comboBoxclass2, sql);
            comboBoxclass2.Items.Clear();
            FillCombobox("SELECT DISTINCT(Class_name) FROM Class_info;", comboBoxclass2);
        }

        private void FillCombobox(string query, ComboBox comboBoxclass2)
        {
            //throw new NotImplementedException();
            string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                comboBoxclass2.Items.Add(reader["Class_name"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void comboBoxrollno_Click(object sender, EventArgs e)
        {
            //comboBoxrollno.Items.Clear();
            //FillCombobox("SELECT DISTINCT(Student_name) FROM Student_info;", comboBoxrollno);

            comboBoxrollno.Items.Clear();

            // Ensure a class is selected from comboBoxclass2
            if (comboBoxclass2.SelectedItem == null)
            {
                    MessageBox.Show("Please select a class first.");
                    return;
            }

            // Get the selected class
           string selectedClass = comboBoxclass2.SelectedItem.ToString();
    
            // Pass the class name to the FillCombobox method to load students for that class
            FillCombobox("SELECT DISTINCT(Student_name) FROM Student_info s INNER JOIN Class_info c ON s.Class_id = c.Class_id WHERE c.Class_name = @ClassName;", comboBoxrollno, selectedClass);
       }

        private void FillCombobox(string p,ComboBox comboBoxrollno,string selectedClass)
        {
     	    string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";

              try
              {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        using (SqlCommand cmd = new SqlCommand(p, connection))
                        {
                                // Add className parameter to filter students by the selected class
                                cmd.Parameters.AddWithValue("@ClassName", selectedClass);
        
                                using (SqlDataReader reader = cmd.ExecuteReader())
                                {
                                    while (reader.Read())
                                    {
                                        comboBoxrollno.Items.Add(reader["Student_name"].ToString());
                                    }
                                }
                       }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
        }

       

        private void comboBoxclass_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (comboBoxclass.SelectedItem == null)
            {
                MessageBox.Show("Please select a class.");
                return;
            }
            string selectedClass = comboBoxclass.SelectedItem.ToString();
            DateTime selectedDate = dateTimePicker2.Value.Date;

            // Load the data for the selected class
            LoadDataForClass(selectedClass);
        }

                
        private void LoadDataForClass(string className)
        {
            string query = @"SELECT s.Student_name, s.Student_rollno, c.Class_name, a.Attandance_date, a.Attandance_status 
                             FROM Student_info s
                             INNER JOIN Attandance_tbl a ON s.Student_id = a.Student_id
                             INNER JOIN Class_info c ON c.Class_id = s.Class_id
                             WHERE c.Class_name = @ClassName";

            try
            {
                string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@ClassName", className);
                        //cmd.Parameters.AddWithValue("@SelectedDate", selectedDate);

                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridViewclassr.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private static void DisplayAndSearchAllData(string p, DataGridView dataGridViewclassr, string sql)
        {
            //throw new NotImplementedException();
        }

        private void comboBoxrollno_SelectedIndexChanged(object sender, EventArgs e)
        {
          
            //if (comboBoxrollno.SelectedItem == null)
            //{
            //    MessageBox.Show("Please select ");
            //    return;
            //}

            if (comboBoxrollno.SelectedItem == null)
            {
                MessageBox.Show("Please select a student.");
                return;
            }

            string selectedStudent = comboBoxrollno.SelectedItem.ToString();

            // Load details for the selected student
            LoadStudentDetails(selectedStudent);
        }

        private void LoadStudentDetails(string selectedStudent)
        {
             string query = @"SELECT s.Student_name, s.Student_rollno, c.Class_name, a.Attandance_date, a.Attandance_status
                     FROM Student_info s
                     INNER JOIN Attandance_tbl a ON s.Student_id = a.Student_id
                     INNER JOIN Class_info c ON c.Class_id = s.Class_id
                     WHERE s.Student_name = @StudentName";

    try
    {
        string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            using (SqlCommand cmd = new SqlCommand(query, connection))
            {
                // Ensure studentName is valid and not empty
                if (string.IsNullOrEmpty(selectedStudent))
                {
                    MessageBox.Show("Student name cannot be empty.");
                    return;
                }

                // Add studentName parameter
                cmd.Parameters.Add("@StudentName", SqlDbType.NVarChar, 50).Value = selectedStudent;

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Load the data into dataGridViewstudentr
                dataGridViewstudentr.DataSource = dataTable;
            }
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show("Error loading student details: " + ex.Message);
    }
        }

       

        private void comboBoxclass2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            //if (comboBoxclass2.SelectedItem == null)
            //{
            //    MessageBox.Show("Please select a class.");
            //    return;
            //}

            if (comboBoxclass2.SelectedItem == null)
            {
                MessageBox.Show("Please select a class.");
                return;
            }

            string selectedClass = comboBoxclass2.SelectedItem.ToString();

            // Load students based on the selected class
            LoadStudentsForClass(selectedClass);
        }

        private void LoadStudentsForClass(string selectedClass)
        {
            string query = @"SELECT s.Student_name
                     FROM Student_info s
                     INNER JOIN Class_info c ON s.Class_id = c.Class_id
                     WHERE c.Class_name = @ClassName";

            try
            {
                string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        // Ensure className is valid and not empty
                        if (string.IsNullOrEmpty(selectedClass))
                        {
                            MessageBox.Show("Class name cannot be empty.");
                            return;
                        }

                        // Add className parameter
                        cmd.Parameters.Add("@ClassName", SqlDbType.NVarChar, 50).Value = selectedClass;

                        SqlDataReader reader = cmd.ExecuteReader();
                        comboBoxrollno.Items.Clear();

                        // Load students into comboBoxrollno
                        while (reader.Read())
                        {
                            comboBoxrollno.Items.Add(reader["Student_name"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading students: " + ex.Message);
            }
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pictureBox1, "Print");
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pictureBox2, "Print");
        }

        private void comboBoxclass_Click(object sender, EventArgs e)
        {
            comboBoxclass.Items.Clear();
            FillCombobox("SELECT DISTINCT(Class_name) FROM Class_info;", comboBoxclass);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //if (printPreviewDialog1.ShowDialog() == DialogResult.OK) ;
            //printDocument1.Print();
                //Graphics g = this.CreateGraphics();
                //bmp = new Bitmap(this.Size.Width, this.Size.Height, g);
                //Graphics mg = Graphics.FromImage(bmp);
                //mg.CopyFromScreen(this.Location.X, this.Location.Y, 0, 280, this.Size);
                //printPreviewDialog1.ShowDialog();

            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
            //printDocument1.Print();
           

        }

        Bitmap bmp;

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("MODI SCHOOL", new Font("Century Gothic", 30, FontStyle.Bold), Brushes.Black, new PointF(280, 50));
            e.Graphics.DrawString("________________________________________________________________________________", new Font("Century Gothic", 25, FontStyle.Bold), Brushes.Black, new PointF(0, 80));
            e.Graphics.DrawString("________________________________________________________________________________", new Font("Century Gothic", 25, FontStyle.Bold), Brushes.Black, new PointF(0, 90));
            e.Graphics.DrawString("Class Report", new Font("Century Gothic", 20, FontStyle.Bold), Brushes.Black, new PointF(300, 150));
            e.Graphics.DrawString("Date: " + dateTimePicker2.Value.ToString("dd-MM-yyyy"), new Font("Century Gothic", 18, FontStyle.Regular), Brushes.Black, new PointF(100, 200));
            e.Graphics.DrawString("Class: " + comboBoxclass.SelectedItem.ToString(), new Font("Century Gothic", 18, FontStyle.Regular), Brushes.Black, new PointF(100, 240));

            Bitmap formImage = new Bitmap(this.Width, this.Height);
            this.DrawToBitmap(formImage, new Rectangle(0, 0, this.Width, this.Height));

            // Print the form image
            e.Graphics.DrawImage(formImage, 0, 280);
            e.Graphics.DrawString("--------------------------------------------------------------------------------", new Font("Century Gothic", 25, FontStyle.Bold), Brushes.Black, new PointF(0, 800));
            e.Graphics.DrawString("Signature", new Font("Century Gothic", 18, FontStyle.Regular), Brushes.Black, new PointF(600, 1000));                                   
           //int startX = 100;
            //int startY = 250;  // Start a bit lower after the date
            //int rowOffset = 0;

            //// Loop through the DataGridView rows and print each cell's value
            //foreach (DataGridViewRow row in dataGridViewclassr.Rows)
            //{
            //    if (!row.IsNewRow)  // Skip the empty new row placeholder
            //    {
            //        // Reset the X position for each row
            //        int cellOffset = 0;

            //        foreach (DataGridViewCell cell in row.Cells)
            //        {
            //            // Ensure the cell value is not null, and replace it with an empty string if it is
            //            string cellValue = cell.Value != null ? cell.Value.ToString() : string.Empty;

            //            // Print the cell value
            //            e.Graphics.DrawString(cellValue,
            //                new Font("Century Gothic", 12, FontStyle.Regular),
            //                Brushes.Black,
            //                new PointF(startX + cellOffset, startY + rowOffset));

            //            // Adjust the cellOffset to move to the next cell (column)
            //            cellOffset += 120;  // Adjust based on your column width
            //        }
            //        // Move to the next row (vertically)
            //        rowOffset += 30;  // Adjust based on your row height
            //    }
            //}
        }

        private void printDocument2_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("MODI SCHOOL", new Font("Century Gothic", 30, FontStyle.Bold), Brushes.Black, new PointF(280, 50));
            e.Graphics.DrawString("________________________________________________________________________________", new Font("Century Gothic", 25, FontStyle.Bold), Brushes.Black, new PointF(0, 80));
            e.Graphics.DrawString("________________________________________________________________________________", new Font("Century Gothic", 25, FontStyle.Bold), Brushes.Black, new PointF(0, 90));
            e.Graphics.DrawString("Student Report", new Font("Century Gothic", 20, FontStyle.Bold), Brushes.Black, new PointF(300, 150));
            e.Graphics.DrawString("Date: " + dateTimePicker1.Value.ToString("dd-MM-yyyy"), new Font("Century Gothic", 18, FontStyle.Regular), Brushes.Black, new PointF(100, 200));
            e.Graphics.DrawString("Class: " + comboBoxclass2.SelectedItem.ToString(), new Font("Century Gothic", 18, FontStyle.Regular), Brushes.Black, new PointF(100, 240));
           // e.Graphics.DrawString("Student: " + comboBoxrollno.SelectedItem.ToString(), new Font("Century Gothic", 18, FontStyle.Regular), Brushes.Black, new PointF(100, 300));

            Bitmap formImage = new Bitmap(this.Width, this.Height);
            this.DrawToBitmap(formImage, new Rectangle(0, 0, this.Width, this.Height));

            // Print the form image
            e.Graphics.DrawImage(formImage, 0, 280);
            e.Graphics.DrawString("--------------------------------------------------------------------------------", new Font("Century Gothic", 25, FontStyle.Bold), Brushes.Black, new PointF(0, 800));
            e.Graphics.DrawString("Signature", new Font("Century Gothic", 18, FontStyle.Regular), Brushes.Black, new PointF(600, 1000));
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            printPreviewDialog2.Document = printDocument2;
            printPreviewDialog2.ShowDialog();
        }

        

        
    }
}
 