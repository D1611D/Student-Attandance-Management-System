﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SASpro_1.Forms.UserControlAddClass
{
    public partial class UserControlAddclass : UserControl
    {
       // private string sql = @"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True";
        private string sql = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";

        string CID = "";

        public UserControlAddclass()
        {
            InitializeComponent();
        }

        public void FirstTab()
        {
            TabControlAddClass.SelectedTab = tabPageaddclass;
        }

        protected override void OnLoad(EventArgs e)
         {
              base.OnLoad(e);

              // Call your method to load data
               LoadData();
         }

          private void LoadData()
          {
                 // Replace this with your actual data retrieval logic
                 var dataSource = GetData();

                   // Bind the data to the DataGridView
                dataGridViewsc.DataSource = dataSource;
         }

          private DataTable GetData()
           {  
                    // Example: Create a DataTable with sample data
               SqlDataAdapter ad = new SqlDataAdapter("Select * from Class_info", sql);
               DataTable dtbl = new DataTable();
               ad.Fill(dtbl);

               dataGridViewsc.DataSource = dtbl;

                    return dtbl;
          }
 

        private void textBoxname_KeyPress(object sender, KeyPressEventArgs e)
        {
            
            if (char.IsControl(e.KeyChar))
            {
                return;
            }

            
            if (char.IsDigit(e.KeyChar))
            {
               
                int digitCount = 0;
                foreach
                (char c in textBoxname.Text)
                {
                    if (char.IsDigit(c))
                    {
                        digitCount++;
                    }
                }

               
                if (digitCount >= 2)
                {
                    e.Handled = true;
                }
            }
        }

       

              
        private void textBoxname2_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (char.IsControl(e.KeyChar))
            {
                return;
            }


            if (char.IsDigit(e.KeyChar))
            {

                int digitCount = 0;
                foreach
                (char c in textBoxname.Text)
                {
                    if (char.IsDigit(c))
                    {
                        digitCount++;
                    }
                }


                if (digitCount >= 2)
                {
                    e.Handled = true;
                }
            }
        }

       

        private void textBoxsearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow control keys like Backspace
            if (char.IsControl(e.KeyChar))
            {
                return;
            }

            // Allow spaces
            if (char.IsWhiteSpace(e.KeyChar))
            {
                return;
            }

            // Check if the input is a letter
            if (char.IsLetter(e.KeyChar))
            {
                return;
            }

            // Allow only 1 or 2 digits in the TextBox
            if (char.IsDigit(e.KeyChar))
            {
                // Count the number of digits already in the TextBox
                int digitCount = textBoxsearch.Text.Count(char.IsDigit);

                if (digitCount < 2) // Allow only 1 or 2 digits
                {
                    return;
                }
            }

            // If the input is not allowed, suppress it
            e.Handled = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pictureBox1, "search");

            string searchTerm = textBoxsearch.Text.Trim().ToLower();

              if (string.IsNullOrWhiteSpace(searchTerm))
              {
                     MessageBox.Show("Please enter a search term.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                       return;
              }

              foreach (DataGridViewRow row in dataGridViewsc.Rows)
              {
                    bool rowMatches = false;

                   foreach (DataGridViewCell cell in row.Cells)
                  {
                       if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchTerm))
                      {
                           row.DefaultCellStyle.BackColor = Color.Yellow; // Highlight the row
                          rowMatches = true;
                          break;
                      }
                 }

                 if (!rowMatches)
                  {
                         row.DefaultCellStyle.BackColor = Color.White; // Reset color if not matching
                    }
         }


      }

        private void button1_Click(object sender, EventArgs e)
        {
            //string connectionString = @"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True";

            string className = textBoxname.Text.Trim();
            //string hms = textBoxhms.Text.Trim();
            //string m = textBoxm.Text.Trim();
            //string f = textBoxf.Text.Trim();

            // Validate the input data before inserting into the database
            if (string.IsNullOrWhiteSpace(className))
            {
                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
          

            try
            {
                //using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True"))
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True"))
                // string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";
                {
                    // Open the database connection
                    connection.Open();

                    // Define the SQL INSERT query with parameters
                    string query = "INSERT INTO Class_info (Class_name) VALUES ('"+textBoxname.Text.ToString()+"')";
                    //SqlCommand command = new SqlCommand(query, connection);

                    

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        

                        // Execute the INSERT command
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Class added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Clear the text boxes after successful insertion
                            textBoxname.Clear();
                            //textBoxhms.Clear();
                            //textBoxm.Clear();
                            //textBoxf.Clear();
                            textBoxname.Focus();

                            LoadData();
                        }

                        else
                        {
                            MessageBox.Show("Failed to add class.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                   
            }
         }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private SqlDataAdapter Fill(DataTable dtbl)
        {
            throw new NotImplementedException();
        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
           if (CID != " ")
            {
                string className = textBoxname2.Text.Trim();
                //string hms = textBoxhms2.Text.Trim();
                //string m = textBoxm2.Text.Trim();
                //string f = textBoxf2.Text.Trim();

                // Validate the input data before inserting into the database
                //if (string.IsNullOrWhiteSpace(className) || string.IsNullOrWhiteSpace(hms) || string.IsNullOrWhiteSpace(m) || string.IsNullOrWhiteSpace(f))
                //{
                //    MessageBox.Show("First Select Rows form table.", "Select rows", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //    return;
                //}
                if (dataGridViewsc.SelectedRows.Count > 0)
                {
                    string originalClassName = dataGridViewsc.SelectedRows[0].Cells["Column2"].Value.ToString();
                }
                else
                {
                    MessageBox.Show("Please select a row.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

            }

           try
            {
                //using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True"))
               using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True"))
                      {
                            // Open the database connection
                            connection.Open();
        
                            // Define the UPDATE query using multiple columns for uniqueness
                            string query = "UPDATE Class_info SET Class_name = @ClassName WHERE Class_name = @OriginalClassName";
        
                            using (SqlCommand command = new SqlCommand(query, connection))
                            {
                                    // Assign values from the text boxes to the parameters
                                        command.Parameters.AddWithValue("@ClassName", textBoxname2.Text);
                                        //command.Parameters.AddWithValue("@ClassHms", textBoxhms2.Text);
                                        //command.Parameters.AddWithValue("@ClassMale", textBoxm2.Text);
                                        //command.Parameters.AddWithValue("@ClassFemale", textBoxf2.Text);
    
                                    // Assign original values from the selected DataGridView row to identify the row
                                        string originalClassName = dataGridViewsc.SelectedRows[0].Cells["Column2"].Value.ToString();
                                        command.Parameters.AddWithValue("@OriginalClassName", originalClassName);
                                        

                                    // Execute the UPDATE command
                                        int rowsAffected = command.ExecuteNonQuery();
        
                                        if (rowsAffected > 0)
                                        {
                                                MessageBox.Show("Class updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
                                                // Clear the text boxes after the update
                                                textBoxname2.Clear();
                                                //textBoxhms2.Clear();
                                                //textBoxm2.Clear();
                                                //textBoxf2.Clear();
    
                                            // Reload the updated data into the DataGridView
                                                LoadData();                 
                                        }
                                        else
                                        {
                                            MessageBox.Show("Failed to update class.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        }
                             }
            }
      }
       catch (Exception ex)
        {   
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }


 }
             
        private void tabPagesearch_Enter(object sender, EventArgs e)
        {
            textBoxsearch.Clear();
            labeltotc.Text = dataGridViewsc.Rows.Count.ToString();
        }

        private void dataGridViewsc_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridViewsc.Rows[e.RowIndex];
                CID = row.Cells[0].Value.ToString();
                textBoxname2.Text = row.Cells [1].Value.ToString();
                //textBoxhms2.Text = row.Cells [2].Value.ToString();
                //textBoxm2.Text = row.Cells [3].Value.ToString();
                //textBoxf2.Text = row.Cells [4].Value.ToString();
            }
        }

        private void buttondelete_Click(object sender, EventArgs e)
        {
            // Connection string 
            //string connectionString = @"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True";
            string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";

            // DELETE query
            string query = "DELETE FROM Class_info WHERE Class_name = '" + textBoxname2.Text.ToString() + "'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Class Record deleted successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            textBoxname2.Clear();
                            //textBoxhms2.Clear();
                            //textBoxm2.Clear();
                            //textBoxf2.Clear();

                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("No Class Record found.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }








        internal static object Count(string p, string sql)
        {
            throw new NotImplementedException();
        }
    }

     
  }

