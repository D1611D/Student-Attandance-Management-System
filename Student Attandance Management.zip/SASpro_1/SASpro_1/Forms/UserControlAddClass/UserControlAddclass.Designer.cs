﻿namespace SASpro_1.Forms.UserControlAddClass
{
    partial class UserControlAddclass
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TabControlAddClass = new System.Windows.Forms.TabControl();
            this.tabPageaddclass = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.panelname = new System.Windows.Forms.Panel();
            this.textBoxname = new System.Windows.Forms.TextBox();
            this.labelname = new System.Windows.Forms.Label();
            this.labeltitle = new System.Windows.Forms.Label();
            this.tabPagesearch = new System.Windows.Forms.TabPage();
            this.labeltotc = new System.Windows.Forms.Label();
            this.labeltc = new System.Windows.Forms.Label();
            this.dataGridViewsc = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelcs = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textBoxsearch = new System.Windows.Forms.TextBox();
            this.labelsearchclass = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabpageuord = new System.Windows.Forms.TabPage();
            this.buttondelete = new System.Windows.Forms.Button();
            this.buttonupdate = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.textBoxname2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.TabControlAddClass.SuspendLayout();
            this.tabPageaddclass.SuspendLayout();
            this.tabPagesearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewsc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabpageuord.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabControlAddClass
            // 
            this.TabControlAddClass.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.TabControlAddClass.Controls.Add(this.tabPageaddclass);
            this.TabControlAddClass.Controls.Add(this.tabPagesearch);
            this.TabControlAddClass.Controls.Add(this.tabpageuord);
            this.TabControlAddClass.Location = new System.Drawing.Point(0, 0);
            this.TabControlAddClass.Name = "TabControlAddClass";
            this.TabControlAddClass.SelectedIndex = 0;
            this.TabControlAddClass.Size = new System.Drawing.Size(1111, 501);
            this.TabControlAddClass.TabIndex = 0;
            // 
            // tabPageaddclass
            // 
            this.tabPageaddclass.BackColor = System.Drawing.Color.Lavender;
            this.tabPageaddclass.Controls.Add(this.button1);
            this.tabPageaddclass.Controls.Add(this.panelname);
            this.tabPageaddclass.Controls.Add(this.textBoxname);
            this.tabPageaddclass.Controls.Add(this.labelname);
            this.tabPageaddclass.Controls.Add(this.labeltitle);
            this.tabPageaddclass.Font = new System.Drawing.Font("Century Gothic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageaddclass.ForeColor = System.Drawing.Color.Blue;
            this.tabPageaddclass.Location = new System.Drawing.Point(4, 4);
            this.tabPageaddclass.Name = "tabPageaddclass";
            this.tabPageaddclass.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageaddclass.Size = new System.Drawing.Size(1103, 475);
            this.tabPageaddclass.TabIndex = 0;
            this.tabPageaddclass.Text = "Add Class";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Blue;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(147, 190);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 47);
            this.button1.TabIndex = 11;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panelname
            // 
            this.panelname.BackColor = System.Drawing.Color.Blue;
            this.panelname.Location = new System.Drawing.Point(80, 144);
            this.panelname.Name = "panelname";
            this.panelname.Size = new System.Drawing.Size(270, 2);
            this.panelname.TabIndex = 0;
            // 
            // textBoxname
            // 
            this.textBoxname.BackColor = System.Drawing.Color.White;
            this.textBoxname.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxname.Location = new System.Drawing.Point(79, 115);
            this.textBoxname.Name = "textBoxname";
            this.textBoxname.Size = new System.Drawing.Size(270, 23);
            this.textBoxname.TabIndex = 1;
            this.textBoxname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxname_KeyPress);
            // 
            // labelname
            // 
            this.labelname.AutoSize = true;
            this.labelname.Font = new System.Drawing.Font("Century Gothic", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelname.Location = new System.Drawing.Point(77, 86);
            this.labelname.Name = "labelname";
            this.labelname.Size = new System.Drawing.Size(68, 18);
            this.labelname.TabIndex = 0;
            this.labelname.Text = "Name :-";
            // 
            // labeltitle
            // 
            this.labeltitle.AutoSize = true;
            this.labeltitle.Font = new System.Drawing.Font("Century Gothic", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltitle.Location = new System.Drawing.Point(10, 11);
            this.labeltitle.Name = "labeltitle";
            this.labeltitle.Size = new System.Drawing.Size(124, 23);
            this.labeltitle.TabIndex = 0;
            this.labeltitle.Text = "Add class...";
            // 
            // tabPagesearch
            // 
            this.tabPagesearch.BackColor = System.Drawing.Color.Lavender;
            this.tabPagesearch.Controls.Add(this.labeltotc);
            this.tabPagesearch.Controls.Add(this.labeltc);
            this.tabPagesearch.Controls.Add(this.dataGridViewsc);
            this.tabPagesearch.Controls.Add(this.labelcs);
            this.tabPagesearch.Controls.Add(this.panel4);
            this.tabPagesearch.Controls.Add(this.textBoxsearch);
            this.tabPagesearch.Controls.Add(this.labelsearchclass);
            this.tabPagesearch.Controls.Add(this.pictureBox1);
            this.tabPagesearch.Location = new System.Drawing.Point(4, 4);
            this.tabPagesearch.Name = "tabPagesearch";
            this.tabPagesearch.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagesearch.Size = new System.Drawing.Size(1103, 475);
            this.tabPagesearch.TabIndex = 1;
            this.tabPagesearch.Text = "Search Class";
            this.tabPagesearch.Enter += new System.EventHandler(this.tabPagesearch_Enter);
            // 
            // labeltotc
            // 
            this.labeltotc.AutoSize = true;
            this.labeltotc.Font = new System.Drawing.Font("Century Gothic", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltotc.ForeColor = System.Drawing.Color.Blue;
            this.labeltotc.Location = new System.Drawing.Point(815, 450);
            this.labeltotc.Name = "labeltotc";
            this.labeltotc.Size = new System.Drawing.Size(26, 18);
            this.labeltotc.TabIndex = 8;
            this.labeltotc.Text = "{?}";
            // 
            // labeltc
            // 
            this.labeltc.AutoSize = true;
            this.labeltc.Font = new System.Drawing.Font("Century Gothic", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltc.ForeColor = System.Drawing.Color.Blue;
            this.labeltc.Location = new System.Drawing.Point(717, 450);
            this.labeltc.Name = "labeltc";
            this.labeltc.Size = new System.Drawing.Size(101, 18);
            this.labeltc.TabIndex = 7;
            this.labeltc.Text = "Total Class :-";
            // 
            // dataGridViewsc
            // 
            this.dataGridViewsc.AllowUserToAddRows = false;
            this.dataGridViewsc.AllowUserToDeleteRows = false;
            this.dataGridViewsc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewsc.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedHeaders;
            this.dataGridViewsc.BackgroundColor = System.Drawing.Color.Lavender;
            this.dataGridViewsc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewsc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewsc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.dataGridViewsc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridViewsc.Location = new System.Drawing.Point(28, 186);
            this.dataGridViewsc.Name = "dataGridViewsc";
            this.dataGridViewsc.ReadOnly = true;
            this.dataGridViewsc.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridViewsc.Size = new System.Drawing.Size(872, 261);
            this.dataGridViewsc.TabIndex = 0;
            this.dataGridViewsc.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewsc_CellClick);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Class_id";
            this.Column1.HeaderText = "id";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "Class_name";
            this.Column2.HeaderText = "Name";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // labelcs
            // 
            this.labelcs.AutoSize = true;
            this.labelcs.Font = new System.Drawing.Font("Century Gothic", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcs.ForeColor = System.Drawing.Color.Blue;
            this.labelcs.Location = new System.Drawing.Point(12, 15);
            this.labelcs.Name = "labelcs";
            this.labelcs.Size = new System.Drawing.Size(143, 23);
            this.labelcs.TabIndex = 6;
            this.labelcs.Text = "Search Class...";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Blue;
            this.panel4.Location = new System.Drawing.Point(109, 138);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(285, 2);
            this.panel4.TabIndex = 2;
            // 
            // textBoxsearch
            // 
            this.textBoxsearch.BackColor = System.Drawing.Color.White;
            this.textBoxsearch.Location = new System.Drawing.Point(109, 112);
            this.textBoxsearch.Name = "textBoxsearch";
            this.textBoxsearch.Size = new System.Drawing.Size(248, 20);
            this.textBoxsearch.TabIndex = 4;
            this.textBoxsearch.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxsearch_KeyPress);
            // 
            // labelsearchclass
            // 
            this.labelsearchclass.AutoSize = true;
            this.labelsearchclass.Font = new System.Drawing.Font("Century Gothic", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsearchclass.ForeColor = System.Drawing.Color.Blue;
            this.labelsearchclass.Location = new System.Drawing.Point(106, 88);
            this.labelsearchclass.Name = "labelsearchclass";
            this.labelsearchclass.Size = new System.Drawing.Size(68, 18);
            this.labelsearchclass.TabIndex = 3;
            this.labelsearchclass.Text = "Name :-";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SASpro_1.Properties.Resources.Search_icon;
            this.pictureBox1.Location = new System.Drawing.Point(357, 112);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(34, 20);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // tabpageuord
            // 
            this.tabpageuord.BackColor = System.Drawing.Color.Lavender;
            this.tabpageuord.Controls.Add(this.buttondelete);
            this.tabpageuord.Controls.Add(this.buttonupdate);
            this.tabpageuord.Controls.Add(this.panel8);
            this.tabpageuord.Controls.Add(this.textBoxname2);
            this.tabpageuord.Controls.Add(this.label4);
            this.tabpageuord.Controls.Add(this.label5);
            this.tabpageuord.Location = new System.Drawing.Point(4, 4);
            this.tabpageuord.Name = "tabpageuord";
            this.tabpageuord.Size = new System.Drawing.Size(1103, 475);
            this.tabpageuord.TabIndex = 2;
            this.tabpageuord.Text = "Update or Delete ";
            // 
            // buttondelete
            // 
            this.buttondelete.BackColor = System.Drawing.Color.Crimson;
            this.buttondelete.Font = new System.Drawing.Font("Century Gothic", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttondelete.ForeColor = System.Drawing.Color.White;
            this.buttondelete.Location = new System.Drawing.Point(221, 192);
            this.buttondelete.Name = "buttondelete";
            this.buttondelete.Size = new System.Drawing.Size(113, 47);
            this.buttondelete.TabIndex = 26;
            this.buttondelete.Text = "Delete";
            this.buttondelete.UseVisualStyleBackColor = false;
            this.buttondelete.Click += new System.EventHandler(this.buttondelete_Click);
            // 
            // buttonupdate
            // 
            this.buttonupdate.BackColor = System.Drawing.Color.Blue;
            this.buttonupdate.Font = new System.Drawing.Font("Century Gothic", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonupdate.ForeColor = System.Drawing.Color.White;
            this.buttonupdate.Location = new System.Drawing.Point(90, 192);
            this.buttonupdate.Name = "buttonupdate";
            this.buttonupdate.Size = new System.Drawing.Size(113, 47);
            this.buttonupdate.TabIndex = 25;
            this.buttonupdate.Text = "Update";
            this.buttonupdate.UseVisualStyleBackColor = false;
            this.buttonupdate.Click += new System.EventHandler(this.buttonupdate_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Blue;
            this.panel8.Location = new System.Drawing.Point(83, 157);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(270, 2);
            this.panel8.TabIndex = 12;
            // 
            // textBoxname2
            // 
            this.textBoxname2.BackColor = System.Drawing.Color.White;
            this.textBoxname2.Location = new System.Drawing.Point(83, 129);
            this.textBoxname2.Name = "textBoxname2";
            this.textBoxname2.Size = new System.Drawing.Size(270, 20);
            this.textBoxname2.TabIndex = 15;
            this.textBoxname2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxname2_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(80, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 18);
            this.label4.TabIndex = 13;
            this.label4.Text = "Name :-";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(10, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(252, 23);
            this.label5.TabIndex = 14;
            this.label5.Text = "Update or Delete Class...";
            // 
            // UserControlAddclass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.TabControlAddClass);
            this.Name = "UserControlAddclass";
            this.Size = new System.Drawing.Size(942, 501);
            this.TabControlAddClass.ResumeLayout(false);
            this.tabPageaddclass.ResumeLayout(false);
            this.tabPageaddclass.PerformLayout();
            this.tabPagesearch.ResumeLayout(false);
            this.tabPagesearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewsc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabpageuord.ResumeLayout(false);
            this.tabpageuord.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl TabControlAddClass;
        private System.Windows.Forms.TabPage tabPageaddclass;
        private System.Windows.Forms.TabPage tabPagesearch;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label labeltitle;
        private System.Windows.Forms.Label labelname;
        private System.Windows.Forms.TextBox textBoxname;
        private System.Windows.Forms.Panel panelname;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox textBoxsearch;
        private System.Windows.Forms.Label labelsearchclass;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelcs;
        private System.Windows.Forms.DataGridView dataGridViewsc;
        private System.Windows.Forms.Label labeltc;
        private System.Windows.Forms.Label labeltotc;
        private System.Windows.Forms.TabPage tabpageuord;
        private System.Windows.Forms.Button buttondelete;
        private System.Windows.Forms.Button buttonupdate;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox textBoxname2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
    }
}
