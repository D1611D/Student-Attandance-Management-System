﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SASpro_1.Forms
{
    public partial class Resetpass : Form
    {
        public Resetpass()
        {
            InitializeComponent();
        }

        private void pictureBoxClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonverify_Click(object sender, EventArgs e)
        {    
            string username = textBox1.Text.ToString();
            string newPassword = textBox2.Text.ToString(); 
           // string connectionString = @"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True";
            string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";

            string query = "UPDATE Userinfotbl SET User_Password = '"+textBox2.Text.ToString()+"' WHERE User_Username = '"+textBox1.Text.ToString()+"'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@NewPassword", textBox1.Text.ToString());
                command.Parameters.AddWithValue("@Username", textBox2.Text.ToString());

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // If the password is updated successfully
                        MessageBox.Show("Password changed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        // If no rows were affected (username might not exist)
                        MessageBox.Show("Username not found in the database..!!.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
     }
  }

