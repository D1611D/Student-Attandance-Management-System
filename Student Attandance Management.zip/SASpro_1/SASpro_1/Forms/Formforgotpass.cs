﻿using SASpro_1.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SASpro_1
{
    public partial class Formforgotpass : Form
    {
        public Formforgotpass()
        {
            InitializeComponent();
        }

        private bool IsValidEmail (String email)
        {
            try
            {
                var addr = new MailAddress(email);
                return addr.Address == email;
            }
            catch 
            {
                return false;
            }
        }

        private void pictureBoxClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
        private void pictureBoxClose_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pictureBoxClose, "Close");
        }

        private void buttonverify_Click(object sender, EventArgs e)
        {
            string securityKey = textBoxSK.Text; 
           // string connectionString =  @"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True";
            string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";
            string query = "SELECT COUNT(*) FROM Security_tbl WHERE Security_Key = @SecurityKey"; // Replace with your table and column

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@SecurityKey", securityKey);

                try
                {
                    connection.Open();
                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        
                        MessageBox.Show("Security key is Valid...Verification Successfull !", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                         Form Resetpass = new Resetpass();
                         Resetpass.ShowDialog();
                         this.Hide();
                    }
                    else
                    {
                       
                        MessageBox.Show("Invalid security key!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
            
    }
}

