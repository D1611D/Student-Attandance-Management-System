﻿namespace SASpro_1
{
    partial class Formmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBoxmini = new System.Windows.Forms.PictureBox();
            this.pictureBoxClose = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.buttonsettings = new System.Windows.Forms.Button();
            this.buttonov = new System.Windows.Forms.Button();
            this.buttonac = new System.Windows.Forms.Button();
            this.buttonas = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panelside = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonattendance = new System.Windows.Forms.Button();
            this.buttondashboard = new System.Windows.Forms.Button();
            this.panelback = new System.Windows.Forms.Panel();
            this.labeltime = new System.Windows.Forms.Label();
            this.labeldate = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.paneltop = new System.Windows.Forms.Panel();
            this.panelexpand = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.userControlDashboard1 = new SASpro_1.Forms.UserControlDashboard.UserControlDashboard();
            this.userControlAddclass1 = new SASpro_1.Forms.UserControlAddClass.UserControlAddclass();
            this.userControlsettings1 = new SASpro_1.Forms.UserControlSettings.UserControlsettings();
            this.userControlAddStudent1 = new SASpro_1.Forms.UserControlAddStudent.UserControlAddStudent();
            this.userControlatt1 = new SASpro_1.Forms.UserControlAttandance.UserControlatt();
            this.userControlreport1 = new SASpro_1.Forms.UsercontrolReport.UserControlreport();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxmini)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxClose)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panelback.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.paneltop.SuspendLayout();
            this.panelexpand.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Lavender;
            this.panel1.Controls.Add(this.pictureBoxmini);
            this.panel1.Controls.Add(this.pictureBoxClose);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1372, 49);
            this.panel1.TabIndex = 1;
            // 
            // pictureBoxmini
            // 
            this.pictureBoxmini.Image = global::SASpro_1.Properties.Resources.minimize_final;
            this.pictureBoxmini.Location = new System.Drawing.Point(1289, 7);
            this.pictureBoxmini.Name = "pictureBoxmini";
            this.pictureBoxmini.Size = new System.Drawing.Size(31, 30);
            this.pictureBoxmini.TabIndex = 3;
            this.pictureBoxmini.TabStop = false;
            this.pictureBoxmini.Click += new System.EventHandler(this.pictureBoxmini_Click);
            // 
            // pictureBoxClose
            // 
            this.pictureBoxClose.Image = global::SASpro_1.Properties.Resources.final_close;
            this.pictureBoxClose.Location = new System.Drawing.Point(1326, 7);
            this.pictureBoxClose.Name = "pictureBoxClose";
            this.pictureBoxClose.Size = new System.Drawing.Size(31, 30);
            this.pictureBoxClose.TabIndex = 2;
            this.pictureBoxClose.TabStop = false;
            this.pictureBoxClose.Click += new System.EventHandler(this.pictureBoxClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(507, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(261, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Attendance Manager";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Blue;
            this.panel3.Controls.Add(this.pictureBox9);
            this.panel3.Controls.Add(this.pictureBox8);
            this.panel3.Controls.Add(this.pictureBox7);
            this.panel3.Controls.Add(this.pictureBox6);
            this.panel3.Controls.Add(this.pictureBox5);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Controls.Add(this.buttonsettings);
            this.panel3.Controls.Add(this.buttonov);
            this.panel3.Controls.Add(this.buttonac);
            this.panel3.Controls.Add(this.buttonas);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.buttonattendance);
            this.panel3.Controls.Add(this.buttondashboard);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(258, 735);
            this.panel3.TabIndex = 0;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::SASpro_1.Properties.Resources.add_business_24dp_FILL0_wght400_GRAD0_opsz24;
            this.pictureBox9.Location = new System.Drawing.Point(15, 339);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(26, 32);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 11;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::SASpro_1.Properties.Resources.overview_24dp_FILL0_wght400_GRAD0_opsz24;
            this.pictureBox8.Location = new System.Drawing.Point(15, 392);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(26, 32);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 10;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::SASpro_1.Properties.Resources.settings_24dp_FILL0_wght400_GRAD0_opsz24__2_;
            this.pictureBox7.Location = new System.Drawing.Point(15, 442);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(26, 32);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 3;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::SASpro_1.Properties.Resources.man_24dp_FILL0_wght400_GRAD0_opsz24;
            this.pictureBox6.Location = new System.Drawing.Point(14, 285);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(26, 32);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 9;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::SASpro_1.Properties.Resources.description_24dp_FILL0_wght400_GRAD0_opsz24;
            this.pictureBox5.Location = new System.Drawing.Point(15, 234);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(26, 32);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 8;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SASpro_1.Properties.Resources.computer_24dp_FILL0_wght400_GRAD0_opsz24__1_;
            this.pictureBox3.Location = new System.Drawing.Point(15, 189);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(26, 32);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // buttonsettings
            // 
            this.buttonsettings.FlatAppearance.BorderSize = 0;
            this.buttonsettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonsettings.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonsettings.ForeColor = System.Drawing.Color.White;
            this.buttonsettings.Location = new System.Drawing.Point(9, 437);
            this.buttonsettings.Name = "buttonsettings";
            this.buttonsettings.Size = new System.Drawing.Size(246, 47);
            this.buttonsettings.TabIndex = 5;
            this.buttonsettings.Text = "           User Settings";
            this.buttonsettings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonsettings.UseVisualStyleBackColor = true;
            this.buttonsettings.Click += new System.EventHandler(this.buttonsettings_Click);
            // 
            // buttonov
            // 
            this.buttonov.FlatAppearance.BorderSize = 0;
            this.buttonov.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonov.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonov.ForeColor = System.Drawing.Color.White;
            this.buttonov.Location = new System.Drawing.Point(9, 384);
            this.buttonov.Name = "buttonov";
            this.buttonov.Size = new System.Drawing.Size(246, 47);
            this.buttonov.TabIndex = 4;
            this.buttonov.Text = "           Report";
            this.buttonov.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonov.UseVisualStyleBackColor = true;
            this.buttonov.Click += new System.EventHandler(this.buttonov_Click);
            // 
            // buttonac
            // 
            this.buttonac.FlatAppearance.BorderSize = 0;
            this.buttonac.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonac.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonac.ForeColor = System.Drawing.Color.White;
            this.buttonac.Location = new System.Drawing.Point(8, 331);
            this.buttonac.Name = "buttonac";
            this.buttonac.Size = new System.Drawing.Size(246, 47);
            this.buttonac.TabIndex = 3;
            this.buttonac.Text = "           Add Class";
            this.buttonac.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonac.UseVisualStyleBackColor = true;
            this.buttonac.Click += new System.EventHandler(this.buttonac_Click);
            // 
            // buttonas
            // 
            this.buttonas.FlatAppearance.BorderSize = 0;
            this.buttonas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonas.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonas.ForeColor = System.Drawing.Color.White;
            this.buttonas.Location = new System.Drawing.Point(9, 279);
            this.buttonas.Name = "buttonas";
            this.buttonas.Size = new System.Drawing.Size(246, 47);
            this.buttonas.TabIndex = 2;
            this.buttonas.Text = "           Add Student";
            this.buttonas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonas.UseVisualStyleBackColor = true;
            this.buttonas.Click += new System.EventHandler(this.buttonas_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panelside);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(0, 180);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(8, 555);
            this.panel5.TabIndex = 2;
            // 
            // panelside
            // 
            this.panelside.BackColor = System.Drawing.Color.White;
            this.panelside.Location = new System.Drawing.Point(0, 0);
            this.panelside.Name = "panelside";
            this.panelside.Size = new System.Drawing.Size(10, 48);
            this.panelside.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.pictureBox4);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(258, 180);
            this.panel4.TabIndex = 0;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::SASpro_1.Properties.Resources.school_24dp_FILL0_wght400_GRAD0_opsz24;
            this.pictureBox4.Location = new System.Drawing.Point(12, 14);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(225, 94);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(90, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 21);
            this.label3.TabIndex = 0;
            this.label3.Text = "system";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(22, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(215, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Attendance Management";
            // 
            // buttonattendance
            // 
            this.buttonattendance.FlatAppearance.BorderSize = 0;
            this.buttonattendance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonattendance.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonattendance.ForeColor = System.Drawing.Color.White;
            this.buttonattendance.Location = new System.Drawing.Point(9, 227);
            this.buttonattendance.Name = "buttonattendance";
            this.buttonattendance.Size = new System.Drawing.Size(246, 47);
            this.buttonattendance.TabIndex = 1;
            this.buttonattendance.Text = "           Attendance";
            this.buttonattendance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonattendance.UseVisualStyleBackColor = true;
            this.buttonattendance.Click += new System.EventHandler(this.buttonattendance_Click);
            // 
            // buttondashboard
            // 
            this.buttondashboard.FlatAppearance.BorderSize = 0;
            this.buttondashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttondashboard.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttondashboard.ForeColor = System.Drawing.Color.White;
            this.buttondashboard.Location = new System.Drawing.Point(8, 180);
            this.buttondashboard.Name = "buttondashboard";
            this.buttondashboard.Size = new System.Drawing.Size(250, 47);
            this.buttondashboard.TabIndex = 0;
            this.buttondashboard.Text = "           Dashboard";
            this.buttondashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttondashboard.UseVisualStyleBackColor = true;
            this.buttondashboard.Click += new System.EventHandler(this.buttondashboard_Click);
            // 
            // panelback
            // 
            this.panelback.Controls.Add(this.labeltime);
            this.panelback.Controls.Add(this.labeldate);
            this.panelback.Controls.Add(this.pictureBox1);
            this.panelback.Controls.Add(this.pictureBox2);
            this.panelback.Controls.Add(this.paneltop);
            this.panelback.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelback.Location = new System.Drawing.Point(258, 0);
            this.panelback.Name = "panelback";
            this.panelback.Size = new System.Drawing.Size(1114, 165);
            this.panelback.TabIndex = 0;
            // 
            // labeltime
            // 
            this.labeltime.AutoSize = true;
            this.labeltime.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltime.ForeColor = System.Drawing.Color.Blue;
            this.labeltime.Location = new System.Drawing.Point(269, 28);
            this.labeltime.Name = "labeltime";
            this.labeltime.Size = new System.Drawing.Size(19, 21);
            this.labeltime.TabIndex = 8;
            this.labeltime.Text = "?";
            // 
            // labeldate
            // 
            this.labeldate.AutoSize = true;
            this.labeldate.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeldate.ForeColor = System.Drawing.Color.Blue;
            this.labeldate.Location = new System.Drawing.Point(39, 28);
            this.labeldate.Name = "labeldate";
            this.labeldate.Size = new System.Drawing.Size(19, 21);
            this.labeldate.TabIndex = 7;
            this.labeldate.Text = "?";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SASpro_1.Properties.Resources.ar01;
            this.pictureBox1.Location = new System.Drawing.Point(1056, 43);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 18);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SASpro_1.Properties.Resources.main_img;
            this.pictureBox2.Location = new System.Drawing.Point(992, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(62, 60);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // paneltop
            // 
            this.paneltop.BackColor = System.Drawing.Color.Blue;
            this.paneltop.Controls.Add(this.label6);
            this.paneltop.Controls.Add(this.label5);
            this.paneltop.Controls.Add(this.panelexpand);
            this.paneltop.Controls.Add(this.label4);
            this.paneltop.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.paneltop.Location = new System.Drawing.Point(0, 65);
            this.paneltop.Name = "paneltop";
            this.paneltop.Size = new System.Drawing.Size(1114, 100);
            this.paneltop.TabIndex = 0;
            // 
            // panelexpand
            // 
            this.panelexpand.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panelexpand.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelexpand.Controls.Add(this.button1);
            this.panelexpand.Location = new System.Drawing.Point(905, 1);
            this.panelexpand.Name = "panelexpand";
            this.panelexpand.Size = new System.Drawing.Size(200, 43);
            this.panelexpand.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(198, 42);
            this.button1.TabIndex = 6;
            this.button1.Text = "Log Out";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(176, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(511, 27);
            this.label4.TabIndex = 0;
            this.label4.Text = "Welcome to Attandance Management System";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panelback);
            this.panel2.Controls.Add(this.userControlDashboard1);
            this.panel2.Controls.Add(this.userControlAddclass1);
            this.panel2.Controls.Add(this.userControlsettings1);
            this.panel2.Controls.Add(this.userControlAddStudent1);
            this.panel2.Controls.Add(this.userControlatt1);
            this.panel2.Controls.Add(this.userControlreport1);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(0, 41);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1372, 735);
            this.panel2.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(15, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 27);
            this.label5.TabIndex = 7;
            this.label5.Text = "Role :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(89, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 27);
            this.label6.TabIndex = 8;
            this.label6.Text = "Admin";
            this.label6.Enter += new System.EventHandler(this.label6_Enter);
            // 
            // userControlDashboard1
            // 
            this.userControlDashboard1.BackColor = System.Drawing.Color.Lavender;
            this.userControlDashboard1.Location = new System.Drawing.Point(258, 165);
            this.userControlDashboard1.Name = "userControlDashboard1";
            this.userControlDashboard1.Size = new System.Drawing.Size(1024, 518);
            this.userControlDashboard1.TabIndex = 14;
            // 
            // userControlAddclass1
            // 
            this.userControlAddclass1.Location = new System.Drawing.Point(258, 165);
            this.userControlAddclass1.Name = "userControlAddclass1";
            this.userControlAddclass1.Size = new System.Drawing.Size(1111, 501);
            this.userControlAddclass1.TabIndex = 12;
            // 
            // userControlsettings1
            // 
            this.userControlsettings1.BackColor = System.Drawing.Color.Lavender;
            this.userControlsettings1.Location = new System.Drawing.Point(258, 165);
            this.userControlsettings1.Name = "userControlsettings1";
            this.userControlsettings1.Size = new System.Drawing.Size(1024, 518);
            this.userControlsettings1.TabIndex = 13;
            this.userControlsettings1.Load += new System.EventHandler(this.userControlsettings1_Load);
            // 
            // userControlAddStudent1
            // 
            this.userControlAddStudent1.BackColor = System.Drawing.Color.Lavender;
            this.userControlAddStudent1.Location = new System.Drawing.Point(258, 165);
            this.userControlAddStudent1.Name = "userControlAddStudent1";
            this.userControlAddStudent1.Size = new System.Drawing.Size(1024, 501);
            this.userControlAddStudent1.TabIndex = 15;
            // 
            // userControlatt1
            // 
            this.userControlatt1.connection = null;
            this.userControlatt1.Location = new System.Drawing.Point(260, 167);
            this.userControlatt1.Name = "userControlatt1";
            this.userControlatt1.Size = new System.Drawing.Size(1024, 518);
            this.userControlatt1.TabIndex = 16;
            // 
            // userControlreport1
            // 
            this.userControlreport1.Location = new System.Drawing.Point(259, 167);
            this.userControlreport1.Name = "userControlreport1";
            this.userControlreport1.Size = new System.Drawing.Size(1024, 518);
            this.userControlreport1.TabIndex = 17;
            // 
            // Formmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SASpro_1.Properties.Resources.pro001;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 681);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Formmain";
            this.ShowIcon = false;
            this.Text = "Attendance management system";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Formmain_Load_1);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxmini)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxClose)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panelback.ResumeLayout(false);
            this.panelback.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.paneltop.ResumeLayout(false);
            this.paneltop.PerformLayout();
            this.panelexpand.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBoxmini;
        private System.Windows.Forms.PictureBox pictureBoxClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonsettings;
        private System.Windows.Forms.Button buttonov;
        private System.Windows.Forms.Button buttonac;
        private System.Windows.Forms.Button buttonas;
        private System.Windows.Forms.Button buttonattendance;
        private System.Windows.Forms.Button buttondashboard;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panelback;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel paneltop;
        private System.Windows.Forms.Panel panelexpand;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label labeldate;
        private Forms.UserControlAddClass.UserControlAddclass userControlAddclass1;
        private Forms.UserControlSettings.UserControlsettings userControlsettings1;
        private Forms.UserControlDashboard.UserControlDashboard userControlDashboard1;
        private Forms.UserControlAddStudent.UserControlAddStudent userControlAddStudent1;
        private Forms.UserControlAttandance.UserControlatt userControlatt1;
        private Forms.UsercontrolReport.UserControlreport userControlreport1;
        private System.Windows.Forms.Label labeltime;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panelside;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
       
        
    }
}