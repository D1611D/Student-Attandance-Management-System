﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SASpro_1
{
    public partial class Formmain2 : Form
    {
        public Formmain2()
        {
            InitializeComponent();
        }

        private void pictureBoxmini_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBoxClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Confirm, Logout...!?", "Logout Confirmation", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                this.Hide();

                Login f1 = new Login();

                f1.ShowDialog();
                this.Close();
            }
            else
            {
                // Do nothing or handle cancellation
            }
        }

        private void Movesidepanel(Control button)
        {
            panelside.Location = new Point(button.Location.X - button.Location.X, button.Location.Y - 180);
        }

        private void buttonattendance_Click(object sender, EventArgs e)
        {
            Movesidepanel(buttonattendance);
            userControlatt1.Visible = true;
            userControlreport1.Visible = false;
            
        }

        private void buttonov_Click(object sender, EventArgs e)
        {
            Movesidepanel(buttonov);
            userControlreport1.Visible = true;
            userControlatt1.Visible = false;
        }

        private void Formmain2_Load(object sender, EventArgs e)
        {
            timer1.Start();
            labeldate.Text = DateTime.Now.ToLongDateString();
            labeltime2.Text = DateTime.Now.ToLongTimeString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            labeltime2.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
        }
    }
}
