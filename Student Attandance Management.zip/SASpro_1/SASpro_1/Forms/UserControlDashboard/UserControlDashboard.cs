﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SASpro_1.Forms.UserControlDashboard
{
    public partial class UserControlDashboard : UserControl
    {
        private string sql = @"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True";

        public UserControlDashboard()
        {
            InitializeComponent();
        }

        public void Count()
        {
            //labelstudent.Text = SASpro_1.Forms.UserControlAddStudent.UserControlAddStudent.Count("SELECT COUNT (*) FROM STUDENT_INFO;", sql).ToString();
            //labelclass.Text = SASpro_1.Forms.UserControlAddClass.UserControlAddclass.Count("SELECT COUNT (*) FROM Class_info1;", sql).ToString();
            //labelstudent.Text = SASpro_1.Forms.UserControlSettings.UserControlsettings.Count("SELECT COUNT (*) FROM Userinfotbl;", sql).ToString();
        }

        private void UserControlDashboard_Load(object sender, EventArgs e)
        {
            Count();

        }

        private void UserControlDashboard_Enter(object sender, EventArgs e)
        {
          // label5.Text = dataGridViewss.Rows.Count.ToString();
        }

       

       


    }
}
