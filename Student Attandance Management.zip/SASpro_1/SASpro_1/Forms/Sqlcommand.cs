﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SASpro_1.Forms
{
    class Sqlcommand
    {
        private string query;
        private string connectionString;
        private System.Data.SqlClient.SqlConnection connection;

        public Sqlcommand(string query, string connectionString)
        {
            // TODO: Complete member initialization
            this.query = query;
            this.connectionString = connectionString;
        }

        public Sqlcommand(string query, System.Data.SqlClient.SqlConnection connection)
        {
            // TODO: Complete member initialization
            this.query = query;
            this.connection = connection;
        }
    }
}
