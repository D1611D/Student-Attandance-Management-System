﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SASpro_1.Forms.UserControlSettings
{
        

    public partial class UserControlsettings : UserControl
    {

       // private string sql = @"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True";
        private string sql = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";

        string CID = "";

        string selectedRole = "";

        public UserControlsettings()
        {
            InitializeComponent();
        }

        public void FirstTab()
        {
            tabControlSettings.SelectedTab = tabPageat;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            // Call your method to load data
            LoadData();
        }

        private void LoadData()
        {
            // Replace this with your actual data retrieval logic
            var dataSource = GetData();

            // Bind the data to the DataGridView
            dataGridViewst.DataSource = dataSource;
        }

        private DataTable GetData()
        {
            // Example: Create a DataTable with sample data
            SqlDataAdapter ad = new SqlDataAdapter("Select * from Userinfotbl", sql);
            DataTable dtbl = new DataTable();
            ad.Fill(dtbl);

            dataGridViewst.DataSource = dtbl;

            return dtbl;
        }

        private void tabpageau_Load(object sender, EventArgs e)
        {
            //con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Dhairya Sem 5\projectdb\projectdb1.mdf;Integrated Security=True;Connect Timeout=30");
            //con.Open();
        }

        
            private void button1_Click(object sender, EventArgs e)
            {
                    string name = textBox1.Text.Trim();
                    string username = textBox2.Text.Trim();
                    string password = textBox3.Text.Trim();
                    string email = textBox4.Text.Trim();
                    string contact = textBox5.Text.Trim();

                    // Validate the input data before inserting into the database
                    if (string.IsNullOrWhiteSpace(contact) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(email))
                    {
                                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                    }
    
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True"))
                            {
                                    connection.Open();
        
                                    // Check if the username already exists
                                    string checkQuery = "SELECT COUNT(1) FROM Userinfotbl WHERE User_username = @username";
                                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, connection))
                                    {
                                            checkCmd.Parameters.AddWithValue("@username", username);
                                            int userExists = (int)checkCmd.ExecuteScalar();
    
                                            if (userExists > 0)
                                            {
                                                    MessageBox.Show("Username already exists! Please choose a different username.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                                    return;
                                            }
                                    }

                                    // Proceed to insert the new record if no duplicates found
                                    string role = "";
                                    if (rdbadmin.Checked == false && rdbuser.Checked == false)
                                    {
                                            MessageBox.Show("Please Select Role..!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            return;
                                    }

                                    role = rdbadmin.Checked ? "Admin" : "User";

                                    // Define the SQL INSERT query with parameters
                                    string query = "INSERT INTO Userinfotbl (User_name, User_username, User_password, User_email, User_contact, User_role) " + "VALUES (@name, @username, @password, @email, @contact, @role)";

                                    using (SqlCommand command = new SqlCommand(query, connection))
                                     {
                                            command.Parameters.AddWithValue("@name", name);
                                            command.Parameters.AddWithValue("@username", username);
                                            command.Parameters.AddWithValue("@password", password);
                                            command.Parameters.AddWithValue("@contact", contact);
                                            command.Parameters.AddWithValue("@email", email);
                                            command.Parameters.AddWithValue("@role", role);

                                            // Execute the INSERT command
                                            int rowsAffected = command.ExecuteNonQuery();
                                            if (rowsAffected > 0)
                                            {
                                                    MessageBox.Show("User added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        
                                                    // Clear the text boxes after successful insertion
                                                    textBox1.Clear();
                                                    textBox2.Clear();
                                                    textBox3.Clear();
                                                    textBox4.Clear();
                                                    textBox5.Clear();
                                                    rdbadmin.Checked = false;
                                                    rdbuser.Checked = false;

                                                    LoadData();
                                            }
                                            else
                                            {
                                                MessageBox.Show("Failed to add user.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            }
                                    }   
                            }
                    }
                    catch (Exception ex)
                    {
                            MessageBox.Show("Error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
            }
    
      
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pictureBox2, "search");

            string searchTerm = textBoxsearch.Text.Trim().ToLower();

            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                MessageBox.Show("Please enter a search term.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            foreach (DataGridViewRow row in dataGridViewst.Rows)
            {
                bool rowMatches = false;

                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchTerm))
                    {
                        row.DefaultCellStyle.BackColor = Color.Yellow; // Highlight the row
                        rowMatches = true;
                        break;
                    }
                }

                if (!rowMatches)
                {
                    row.DefaultCellStyle.BackColor = Color.White; // Reset color if not matching
                }
                textBoxsearch.Clear();
            }
        }

        private void textBoxsearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar))
            {
                return;
            }


            if (char.IsDigit(e.KeyChar))
            {

                int digitCount = 0;
                foreach
                (char c in textBoxsearch.Text)
                {
                    if (char.IsDigit(c))
                    {
                        digitCount++;
                    }
                }


                if (digitCount >= 2)
                {
                    e.Handled = true;
                }
            }
        }

        private void dataGridViewst_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridViewst.Rows[e.RowIndex];
            CID = row.Cells[0].Value.ToString();
            textBox12.Text = row.Cells[1].Value.ToString();
            textBox11.Text = row.Cells[2].Value.ToString();
            textBox10.Text = row.Cells[3].Value.ToString();
            textBox9.Text = row.Cells[4].Value.ToString();
            textBox8.Text = row.Cells[6].Value.ToString();

            string role = row.Cells[5].Value.ToString().Trim();

            if (role == "Admin")
            {
                radioButton2.Checked = true;
            }
            else if (role == "User")
            {
                radioButton1.Checked = true;
            }
            else
            {
                radioButton2.Checked = false;
                radioButton1.Checked = false;
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Connection string to your database
            //string connectionString = @"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True";
            string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";

            // SQL DELETE query
            string query = "DELETE FROM userinfotbl WHERE User_name = '" + textBox12.Text.ToString() + "' AND User_username = '" + textBox11.Text.ToString() + "' AND User_password = '" + textBox10.Text.ToString() + "' AND User_email = '" + textBox9.Text.ToString() + "' AND User_contact = '" + textBox8.Text.ToString() + "'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("User Record deleted successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            textBox12.Clear();
                            textBox11.Clear();
                            textBox10.Clear();
                            textBox9.Clear();
                            textBox8.Clear();

                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("No User Record found.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        internal static object Count(string p, string sql)
        {
            throw new NotImplementedException();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (CID != " ")
            {
                string Name = textBox12.Text.Trim();
                string Username = textBox11.Text.Trim();
                string Password = textBox10.Text.Trim();
                string Email = textBox9.Text.Trim();
                string Contact = textBox8.Text.Trim();

                
                    
                if (radioButton2.Checked)
                {
                    selectedRole = "Admin";
                }
                else if (radioButton1.Checked)
                {
                    selectedRole = "User";
                }

                if (dataGridViewst.SelectedRows.Count > 0)
                {
                    string originalUserName = dataGridViewst.SelectedRows[0].Cells["Column2"].Value.ToString();
                }
                else
                {
                    MessageBox.Show("Please select a row.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

            }

            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True"))
                {
                    // Open the database connection
                    connection.Open();

                    // Define the UPDATE query using multiple columns for uniqueness
                    string query = "UPDATE userinfotbl SET User_name = @User_name, User_username = @User_username, User_password = @User_password, User_email = @User_email, User_contact = @User_contact, User_role = @User_role WHERE User_name = @OriginalUserName";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Assign values from the text boxes to the parameters
                        command.Parameters.AddWithValue("@User_name", textBox12.Text);
                        command.Parameters.AddWithValue("@User_username", textBox11.Text);
                        command.Parameters.AddWithValue("@User_password", textBox10.Text);
                        command.Parameters.AddWithValue("@User_email", textBox9.Text);
                        command.Parameters.AddWithValue("@User_contact", textBox8.Text);
                        command.Parameters.AddWithValue("@User_role", selectedRole); 

                        // Assign original values from the selected DataGridView row to identify the row
                        string originalUserName = dataGridViewst.SelectedRows[0].Cells["Column2"].Value.ToString();
                        command.Parameters.AddWithValue("@OriginalUserName", originalUserName);


                        // Execute the UPDATE command
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Class updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Clear the text boxes after the update
                            textBox12.Clear();
                            textBox11.Clear();
                            textBox10.Clear();
                            textBox9.Clear(); 
                            textBox8.Clear();
                            radioButton1.Checked = false;
                            radioButton2.Checked = false;
                            
                            // Reload the updated data into the DataGridView
                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("Failed to update class.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tabPagesearch_Enter(object sender, EventArgs e)
        {
            textBoxsearch.Clear();
            labeltotu.Text = dataGridViewst.Rows.Count.ToString();
        }

      
    }
}
