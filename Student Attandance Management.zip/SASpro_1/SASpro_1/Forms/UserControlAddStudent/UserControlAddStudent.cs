﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SASpro_1.Forms.UserControlAddStudent
{
    public partial class UserControlAddStudent : UserControl
    {
       // private string sql = @"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True";
        private string sql = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";

        string CID = "";

        string selectedgender = " ";

        public UserControlAddStudent()
        {
            InitializeComponent();
             LoadClassNames();
             dataGridViewss.Columns["Column6"].Visible = false;

        }

        public void FirstTab()
        {
            tabControlAddStudent.SelectedTab = tabPageas;
        }

         private void LoadClassNames()
        {
            //string connectionString =@"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True"; 
            string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";
            string query = "SELECT Class_name FROM Class_info"; 

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataReader reader = cmd.ExecuteReader();

                    comboBoxclass.Items.Clear(); // Clear existing items

                    while (reader.Read())
                    {
                        comboBoxclass.Items.Add(reader["Class_name"].ToString());
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
    


        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            // Call your method to load data
            LoadData();
        }

        private void LoadData()
        {
            // Replace this with your actual data retrieval logic
            var dataSource = GetData();

            // Bind the data to the DataGridView
            dataGridViewss.DataSource = dataSource;
        }

        private DataTable GetData()
        {
            // Example: Create a DataTable with sample data
            SqlDataAdapter ad = new SqlDataAdapter("Select * from Student_info", sql);
            DataTable dtbl = new DataTable();
            ad.Fill(dtbl);

            dataGridViewss.DataSource = dtbl;

            return dtbl;
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pictureBox1, "search");

            string searchTerm = textBoxns.Text.Trim().ToLower();

            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                MessageBox.Show("Please enter a search term.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            foreach (DataGridViewRow row in dataGridViewss.Rows)
            {
                bool rowMatches = false;

                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchTerm))
                    {
                        row.DefaultCellStyle.BackColor = Color.Yellow; // Highlight the row
                        rowMatches = true;
                        break;
                    }
                }

                if (!rowMatches)
                {
                    row.DefaultCellStyle.BackColor = Color.White; // Reset color if not matching
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string rollno = textBoxrn.Text.Trim();
            string name = textBoxname.Text.Trim();
            string Class = comboBoxclass.Text.Trim();

            // Validate the input data before inserting into the database
            if (string.IsNullOrWhiteSpace(rollno) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(Class))
            {
                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True"))
                {
                    // Open the database connection
                    connection.Open();

                    string gender = "";
                    if (radioButton1.Checked == false && radioButton2.Checked == false)
                    {
                        MessageBox.Show("Please Select Gender..!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                        gender = radioButton1.Checked ? "male" : "female";
                    }

                    // Step 1: Retrieve Class_id based on selected Class_name
                    string classIdQuery = "SELECT Class_id FROM Class_info WHERE Class_name = @className";
                    int classId = 0;

                    using (SqlCommand classCmd = new SqlCommand(classIdQuery, connection))
                    {
                        classCmd.Parameters.AddWithValue("@className", Class);
                        object result = classCmd.ExecuteScalar();

                        if (result != null)
                        {
                            classId = Convert.ToInt32(result);  // Class_id found
                        }
                        else
                        {
                            MessageBox.Show("Class not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;  // Exit if the class is not found
                        }
                    }

                    // Step 2: Insert into Student_info along with Class_id
                    string query = "INSERT INTO Student_info (Student_rollno, Student_name, Student_class, Student_gender, Class_id) " +
                                   "VALUES (@rollno, @name, @class, @gender, @classId)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@rollno", rollno);
                        command.Parameters.AddWithValue("@name", name);
                        command.Parameters.AddWithValue("@class", Class);
                        command.Parameters.AddWithValue("@gender", gender);
                        command.Parameters.AddWithValue("@classId", classId);  // Adding the retrieved Class_id

                        // Execute the INSERT command
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Student added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Clear the text boxes after successful insertion
                            textBoxrn.Clear();
                            textBoxname.Clear();
                            comboBoxclass.SelectedItem = null;
                            radioButton1.Checked = false;
                            radioButton2.Checked = false;
                            textBoxrn.Focus();

                            LoadData(); 
                        }
                        else
                        {
                            MessageBox.Show("Failed to add student.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void dataGridViewss_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridViewss.Rows[e.RowIndex];
                CID = row.Cells[0].Value.ToString();
                textBoxr.Text = row.Cells[1].Value.ToString();
                textBoxnm.Text = row.Cells[2].Value.ToString();
                textBoxc.Text = row.Cells[3].Value.ToString();

                string gender = row.Cells[4].Value.ToString().Trim();

                if (gender == "female")
                {
                    radioButton3.Checked = true;
                }
                else if (gender == "male")
                {
                    radioButton4.Checked = true;
                }
                else
                {
                    radioButton3.Checked = false;
                    radioButton4.Checked = false;
                }
            }
        }

        private void tabPagess_Enter(object sender, EventArgs e)
        {
            textBoxns.Clear();
            labeltots.Text = dataGridViewss.Rows.Count.ToString();
        }

        private void buttondelete_Click(object sender, EventArgs e)
        {
            // Connection string to your database
            //string connectionString = @"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True";
            string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";

            // SQL DELETE query
            string query = "DELETE FROM Student_info WHERE Student_rollno = '" + textBoxr.Text.ToString() + "' AND Student_name = '" + textBoxnm.Text.ToString() + "' AND Student_class = '" + textBoxc.Text.ToString() + "'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Student Record deleted successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            textBoxr.Clear();
                            textBoxnm.Clear();
                            textBoxc.Clear();
                            radioButton3.Checked = false;
                            radioButton4.Checked = false;

                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("No Student Record found.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
            if (CID != " ")
            {
                string rollno = textBoxr.Text.Trim();
                string name = textBoxnm.Text.Trim();
                string Class = textBoxc.Text.Trim();

                    

                if (radioButton4.Checked)
                {
                    selectedgender = "Male";
                }
                else if (radioButton3.Checked)
                {
                    selectedgender = "Female";
                }

                if (dataGridViewss.SelectedRows.Count > 0)
                {
                    string originalStudentrollno = dataGridViewss.SelectedRows[0].Cells["Column2"].Value.ToString();
                }
                else
                {
                    MessageBox.Show("Please select a row.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

            }

            try
            {
                //using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\SQLEXPRESS;Initial Catalog=projectdb;Integrated Security=True"))
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True"))
                {
                    // Open the database connection
                    connection.Open();

                    // Define the UPDATE query using multiple columns for uniqueness
                    string query = "UPDATE Student_info SET Student_rollno = @Student_rollno, Student_name = @Student_name, Student_class = @Student_class, Student_gender = @Student_gender WHERE Student_rollno = @OriginalStudentrollno ";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Assign values from the text boxes to the parameters
                        command.Parameters.AddWithValue("@Student_rollno", textBoxr.Text);
                        command.Parameters.AddWithValue("@Student_name", textBoxnm.Text);
                        command.Parameters.AddWithValue("@Student_class", textBoxc.Text);
                        command.Parameters.AddWithValue("@Student_gender", selectedgender);


                        // Assign original values from the selected DataGridView row to identify the row
                        string originalStudentrollno = dataGridViewss.SelectedRows[0].Cells["Column2"].Value.ToString();
                        command.Parameters.AddWithValue("@OriginalStudentrollno", originalStudentrollno);


                        // Execute the UPDATE command
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Class updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Clear the text boxes after the update
                            textBoxr.Clear();
                            textBoxnm.Clear();
                            textBoxc.Clear();
                            radioButton3.Checked = false;
                            radioButton4.Checked = false;


                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("Failed to update class.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
    }
}
