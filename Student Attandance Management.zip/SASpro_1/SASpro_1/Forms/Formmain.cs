﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SASpro_1
{
    public partial class Formmain : Form
    {
       
      SqlConnection con;
        

       // private Timer timer;
               
        public Formmain()
        {
            InitializeComponent();
            
        }

        private void Movesidepanel(Control button)
        {
            panelside.Location = new Point(button.Location.X - button.Location.X, button.Location.Y - 180);
        }
      
       

        private void pictureBoxClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBoxmini_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Confirm, Logout...!?", "Logout Confirmation", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                this.Hide();

                Login f1 = new Login();

                f1.ShowDialog();
                this.Close();
            }
            else
            {
                // Do nothing or handle cancellation
            }
            

        }

        private void Formmain_Load(object sender, EventArgs e)
        {
            //con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\Dhairya Sem 5\projectdb\projectdb1.mdf;Integrated Security=True;Connect Timeout=30");
            con = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True; Connect Timeout=30");
            con.Open();
             
        }

      

       private void buttondashboard_Click(object sender, EventArgs e)
        {
           Movesidepanel(buttondashboard);
           userControlDashboard1.Visible = true;
           userControlAddclass1.Visible = false;
           userControlAddStudent1.Visible = false;
           userControlatt1.Visible = false;
           userControlreport1.Visible = false;

        }

      
       private void buttonattendance_Click(object sender, EventArgs e)
       {
           Movesidepanel(buttonattendance);
           userControlatt1.Visible = true;
           userControlDashboard1.Visible = false;
           userControlAddclass1.Visible = false;
           userControlsettings1.Visible = false;
           userControlAddStudent1.Visible = false;
           userControlreport1.Visible = false;
           
       }

       private void buttonas_Click(object sender, EventArgs e)
       {
           Movesidepanel(buttonas);
           userControlDashboard1.Visible = false;
           userControlAddclass1.Visible = false;
           userControlsettings1.Visible = false;
           userControlAddStudent1.Visible = true;
           userControlatt1.Visible = false;
           userControlreport1.Visible = false;

       }

       private void buttonac_Click(object sender, EventArgs e)
       {
           Movesidepanel(buttonac);
           userControlDashboard1.Visible = false;
           userControlAddclass1.Visible = true;
           userControlsettings1.Visible = false;
           userControlAddStudent1.Visible = false;
           userControlatt1.Visible = false;
           userControlreport1.Visible = false;

       }

       private void buttonov_Click(object sender, EventArgs e)
       {
           Movesidepanel(buttonov);
           userControlDashboard1.Visible = false;
           userControlAddclass1.Visible = false;
           userControlsettings1.Visible = false;
           userControlAddStudent1.Visible = false;
           userControlatt1.Visible = false;
           userControlreport1.Visible = true;

       }

       private void buttonsettings_Click(object sender, EventArgs e)
       {
           Movesidepanel(buttonsettings);
           userControlsettings1.Visible = true;
           userControlDashboard1.Visible = false;
           userControlAddclass1.Visible = false;
           userControlAddStudent1.Visible = false;
           userControlatt1.Visible = false;
           userControlreport1.Visible = false;
       }

       private void userControlDashboard1_Load(object sender, EventArgs e)
       {

       }

       private void userControlsettings1_Load(object sender, EventArgs e)
       {

       }

       private void Formmain_Load_1(object sender, EventArgs e)
       {
           timer1.Start();
           labeldate.Text = DateTime.Now.ToLongDateString();
           labeltime.Text = DateTime.Now.ToLongTimeString();
       }

       private void timer1_Tick(object sender, EventArgs e)
       {
           labeltime.Text = DateTime.Now.ToLongTimeString();
           timer1.Start();

       }

       private void label6_Enter(object sender, EventArgs e)
       {
           
       }

      
     }

     
       
    }
       

