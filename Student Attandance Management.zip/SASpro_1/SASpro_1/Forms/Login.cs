﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SASpro_1.Forms;

namespace SASpro_1
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            textBox1.Focus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBoxHide.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBoxshow_Click(object sender, EventArgs e)
        {
            textBox01.UseSystemPasswordChar = false;
            pictureBoxshow.Hide();
            pictureBoxHide.Show();
        }

        private void pictureBoxHide_Click(object sender, EventArgs e)
        {
            textBox01.UseSystemPasswordChar = true;
            pictureBoxshow.Show();
            pictureBoxHide.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=projectdb;Integrated Security=True";
            string username = textBox1.Text.Trim();
            string password = textBox01.Text.Trim();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Updated query to select the User_role along with User_username and User_password
                    string query = "SELECT User_role FROM Userinfotbl WHERE User_Username = @username AND User_Password = @password";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Adding parameters to avoid SQL Injection
                        command.Parameters.AddWithValue("@username", username);
                        command.Parameters.AddWithValue("@password", password);

                        SqlDataAdapter ad = new SqlDataAdapter(command);
                        DataTable userTable = new DataTable();
                        ad.Fill(userTable);

                        if (userTable.Rows.Count > 0)
                        {
                            // Fetch the role from the database
                            string role = userTable.Rows[0]["User_role"].ToString();

                            // Navigate based on the role
                            if (role.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                            {
                                this.Hide();
                                Form formmain = new Formmain();
                                formmain.ShowDialog();
                                this.Close();
                            }
                            else if (role.Equals("User", StringComparison.OrdinalIgnoreCase))
                            {
                                this.Hide();
                                Form formmain2 = new Formmain2();
                                formmain2.ShowDialog();
                                this.Close();
                            }
                        }
                        else
                        {
                            // If no user is found with the provided username and password
                            MessageBox.Show("Invalid 'Username' or 'Password'", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            textBox1.Clear();
                            textBox01.Clear();
                            textBox1.Focus();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while trying to log in. Please try again. " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Clear();
                textBox01.Clear();
                textBox1.Focus();
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Formforgotpass formforgotpass = new Formforgotpass();
            formforgotpass.ShowDialog();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form formsignup = new Formsignup();
            formsignup.ShowDialog();
            this.Close();
        }
         private void pictureBoxClose_MouseHover(object sender, EventArgs e)
        {
            toolTip.SetToolTip(pictureBoxClose, "Close");
        }

         private void pictureBoxmini_MouseHover(object sender, EventArgs e)
         {
             toolTip.SetToolTip(pictureBoxmini, "Minimize");
         }
         void textBox2_KeyUp(object sender, KeyEventArgs e)
         {
             if (e.KeyCode == Keys.Enter)
                 e.SuppressKeyPress = true;
         }

         private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
         {
             if (e.KeyChar == (char)Keys.Enter)
             {
                 button1.PerformClick();
                 e.Handled = true;
             }
         }
        private void pictureBoxshow_MouseHover(object sender, EventArgs e)
         {
             toolTip.SetToolTip(pictureBoxshow, "Show Password");
         }

        private void pictureBoxHide_MouseHover(object sender, EventArgs e)
        {
            toolTip.SetToolTip(pictureBoxHide, "Hide Password");
        }
    }
}

